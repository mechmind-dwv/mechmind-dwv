
📁 mechmind-dwv/
├── .github/
│   ├── workflows/       # Flujos automáticos
│   └── codeql/          # Consultas seguridad
├── docs/
│   ├── robotics/        # Docs MechBot
│   └── assets/style.html # Estilos
└── projects/
    └── mechbot-2x/      # Código principal

